﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp25
{
    public partial class Form1 : Form
    {
        private double[] array;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = (int)numericUpDown1.Value;
            array = new double[n];
            Random random = new Random();

            for (int i = 0; i < n; i++)
            {
                array[i] = random.NextDouble() * (random.Next(2) == 0 ? -1 : 1);
            }

            textBox1.Text = string.Join(", ", array);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (array == null)
            {
                MessageBox.Show("Масив не згенеровано!");
                return;
            }

            int maxModulusIndex = 0;

            for (int i = 1; i < array.Length; i++)
            {
                if (Math.Abs(array[i]) > Math.Abs(array[maxModulusIndex]))
                {
                    maxModulusIndex = i;
                }
            }

            textBox2.Text = $"Номер максимального за модулем елемента: {maxModulusIndex}";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (array == null)
            {
                MessageBox.Show("Масив не згенеровано!");
                return;
            }

            double sum = 0;
            bool foundPositive = false;

            for (int i = 0; i < array.Length; i++)
            {
                if (foundPositive)
                {
                    sum += array[i];
                }
                else if (array[i] > 0)
                {
                    foundPositive = true;
                }
            }

            textBox3.Text = $"Сума елементів після першого додатнього елемента: {sum}";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (array == null)
            {
                MessageBox.Show("Масив не згенеровано!");
                return;
            }

            double[] sortedArray = array.OrderBy(x => (int)x == x ? 0 : 1).ToArray();
            textBox4.Text = string.Join(", ", sortedArray);
        }
    }
}
