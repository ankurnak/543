﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp26
{
    public partial class Form1 : Form
    {
        private int[,] array = new int[5, 5]
        {
            { 1, 2, 3, 4, 5 },
            { 6, 7, 8, 9, 10 },
            { 11, 12, 13, 14, 15 },
            { 16, 17, 18, 19, 20 },
            { 21, 22, 23, 24, 25 }
        };
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sum = array[0, 0] + array[4, 4];
            textBox1.Text = $"Сума елементів у верхньому лівому та нижньому правому кутках: {sum}";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int sum = array[0, 0] + array[0, 4] + array[4, 0] + array[4, 4];
            double average = (double)sum / 4;
            textBox2.Text = $"Середнє арифметичне елементів у чотирьох кутках: {average}";
        }
    }
}
